<?php if (!defined('CERTIFICATE_RENDER')) {http_response_code(404);exit;} ?>
<article class="certificate <?= $p['background_id']?'custom-background':'' ?> <?= $p['layout']['show_border']?'with-border':'' ?>" style="<?= h($style) ?>">
 <?php if ($p['background_id']): ?><img class="background" src="media.php?id=<?= (int)$p['background_id'] ?>" alt=""><?php endif; ?>
 <div class="border outer"></div><div class="border inner"></div>
 <div class="cert-line school" data-position="school_y"><?= h($p['school']) ?></div>
 <div class="cert-line heading" data-position="heading_y">เกียรติบัตร</div>
 <div class="cert-line intro" data-position="intro_y">ขอมอบเกียรติบัตรฉบับนี้ให้ไว้เพื่อแสดงว่า</div>
 <div class="cert-line student" data-position="name_y"><?= h($r['full_name']) ?></div>
 <div class="cert-line award" data-position="award_y"><?= h($p['award']) ?></div>
 <div class="cert-line project-name" data-position="project_y"><?= h($p['title']) ?></div>
 <div class="cert-line date" data-position="date_y">ให้ไว้ ณ วันที่ <?= h(thai_date($p['certificate_date'])) ?></div>
 <?php if ($p['signature_id']): ?><div class="cert-line signature" data-position="signature_y"><img src="media.php?id=<?= (int)$p['signature_id'] ?>" alt="ลายเซ็นผู้ลงนาม"></div><?php endif; ?>
 <div class="cert-line signer" data-position="signer_y"><?= $p['signer_name']!==''?'('.h($p['signer_name']).')':'' ?></div>
 <div class="cert-line position" data-position="position_y"><?= h($p['signer_position']) ?></div>
 <div class="serial">เลขที่ <?= h($r['certificate_number']) ?></div>
</article>
