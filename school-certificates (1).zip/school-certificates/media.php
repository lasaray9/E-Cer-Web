<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';session_write_close();
try {
 $id=record_id($_GET);$q=db()->prepare('SELECT filename,mime FROM media WHERE id=?');$q->execute([$id]);$m=$q->fetch();
 if (!$m||!preg_match('/^[a-f0-9]{40}\.bin$/D',$m['filename'])||!in_array($m['mime'],['image/png','image/jpeg'],true)) {http_response_code(404);exit;}
 $path=__DIR__.'/storage/'.$m['filename'];if (!is_file($path)) {http_response_code(404);exit;}
 header('Content-Type: '.$m['mime']);header('Content-Length: '.filesize($path));readfile($path);
} catch(Throwable $e) {error_log((string)$e);http_response_code(404);}
