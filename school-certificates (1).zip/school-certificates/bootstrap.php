<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Bangkok');
ini_set('display_errors','0');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store');
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1','::1'],true)) {
 http_response_code(403); exit('ระบบรุ่นนี้สำหรับใช้งานบนเครื่องที่ติดตั้งผ่าน localhost เท่านั้น');
}
session_name('school_certificates');
session_start(['cookie_httponly'=>true,'cookie_samesite'=>'Strict','cookie_secure'=>isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off','use_strict_mode'=>true]);
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
function db(): PDO {
 static $pdo;
 if (!$pdo) {
  $c=require __DIR__.'/config.php';
  $pdo=new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['database']};charset=utf8mb4",$c['username'],$c['password'],[
   PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
 }
 return $pdo;
}
function out(array $data,int $status=200): void {
 http_response_code($status); header('Content-Type: application/json; charset=utf-8');
 echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR); exit;
}
function text_input(array $a,string $key,string $default=''): string {
 $v=$a[$key]??$default; if (!is_string($v)) throw new InvalidArgumentException('รูปแบบข้อมูลไม่ถูกต้อง'); return trim($v);
}
function field(array $a,string $key,int $max,bool $required=true): string {
 $s=text_input($a,$key); $n=preg_match_all('/./us',$s);
 if ($n===false || $n>$max || ($required && $s==='')) throw new InvalidArgumentException("กรุณาตรวจสอบ $key (สูงสุด $max ตัวอักษร)");
 return $s;
}
function record_id(array $a,string $key='id'): int {
 $s=text_input($a,$key); if (!ctype_digit($s)||strlen($s)>10||(int)$s<1) throw new InvalidArgumentException('รหัสรายการไม่ถูกต้อง'); return (int)$s;
}
function h($s): string {return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function defaults(): array {
 return ['school_y'=>14,'heading_y'=>25,'intro_y'=>33,'name_y'=>43,'award_y'=>52,'project_y'=>60,'date_y'=>69,'signature_y'=>76,'signer_y'=>85,'position_y'=>91,'name_size'=>38,'text_color'=>'#172c49','show_border'=>true];
}
function layout(array $source): array {
 $result=defaults();
 foreach ($result as $key=>$default) {
  if (!array_key_exists($key,$source)) continue;
  $v=$source[$key];
  if ($key==='text_color') {
   if (!is_string($v)||!preg_match('/^#[a-fA-F0-9]{6}$/D',$v)) throw new InvalidArgumentException('สีข้อความไม่ถูกต้อง');
  } elseif ($key==='show_border') {
   if (!is_bool($v)) throw new InvalidArgumentException('ค่ากรอบเกียรติบัตรไม่ถูกต้อง');
  } else {
   $min=$key==='name_size'?20:5; $max=$key==='name_size'?56:95;
   if (!is_numeric($v)||(float)$v<$min||(float)$v>$max) throw new InvalidArgumentException('ตำแหน่งหรือขนาดข้อความไม่ถูกต้อง');
   $v=(float)$v;
  }
  $result[$key]=$v;
 }
 return $result;
}
function project(int $id): array {
 $q=db()->prepare('SELECT * FROM projects WHERE id=?'); $q->execute([$id]); $p=$q->fetch();
 if (!$p) throw new InvalidArgumentException('ไม่พบโครงการ');
 $p['layout']=layout(json_decode($p['layout_json'],true,512,JSON_THROW_ON_ERROR)); unset($p['layout_json']); return $p;
}
function thai_date(string $date): string {
 $d=new DateTimeImmutable($date); $m=['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
 return $d->format('j').' '.$m[(int)$d->format('n')-1].' พ.ศ. '.((int)$d->format('Y')+543);
}
