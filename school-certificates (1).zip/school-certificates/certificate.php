<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';session_write_close();
try {
 $p=project(record_id($_GET,'project_id'));
 $sample=text_input($_GET,'sample')==='1';
 if ($sample) {$rows=[['full_name'=>'เด็กหญิงตัวอย่าง ใจดี','certificate_number'=>'ตัวอย่าง']];}
 else {
  $raw=text_input($_GET,'ids');
  if (!preg_match('/^[0-9]+(?:,[0-9]+){0,99}$/D',$raw)||strlen($raw)>1100) throw new InvalidArgumentException('กรุณาเลือก 1–100 รายชื่อที่จะพิมพ์');
  $ids=array_values(array_unique(array_map('intval',explode(',',$raw))));
  $marks=implode(',',array_fill(0,count($ids),'?'));
  $q=db()->prepare("SELECT * FROM recipients WHERE project_id=? AND id IN ($marks) ORDER BY id ASC");$q->execute([$p['id'],...$ids]);$rows=$q->fetchAll();
  if (count($rows)!==count($ids)) throw new InvalidArgumentException('มีรายชื่อที่ถูกลบหรือไม่อยู่ในโครงการนี้ กรุณารีเฟรชแล้วเลือกใหม่');
 }
 $style='--text-color:'.$p['layout']['text_color'].';--name-size:'.$p['layout']['name_size'].'px;';
 foreach ($p['layout'] as $key=>$v) if (str_ends_with($key,'_y')) $style.='--'.$key.':'.$v.'%;';
 define('CERTIFICATE_RENDER',true);
} catch(Throwable $e) {
 http_response_code($e instanceof InvalidArgumentException?422:500);error_log((string)$e);
 exit(h($e instanceof InvalidArgumentException?$e->getMessage():'เปิดเกียรติบัตรไม่สำเร็จ กรุณาตรวจสอบฐานข้อมูล'));
}
?><!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?= h($p['title']) ?> — เกียรติบัตร</title><link rel="stylesheet" href="assets/certificate.css"><script defer src="assets/certificate.js"></script></head>
<body class="<?= $sample && text_input($_GET,'embed')==='1'?'sample':'' ?>">
<div class="print-toolbar"><div><strong><?= $sample?'ตัวอย่างการจัดวาง':count($rows).' เกียรติบัตร' ?></strong><span id="print-status"><?= $sample?'ชื่อและเลขที่นี้เป็นข้อมูลตัวอย่าง':'ตั้งค่ากระดาษ A4 · แนวนอน · ขอบไม่มี · ปิดส่วนหัวและท้ายกระดาษ' ?></span></div><?php if (!$sample): ?><button id="print-button" disabled>กำลังเตรียมภาพ…</button><?php endif; ?></div>
<main id="sheets"><?php foreach($rows as $r) require __DIR__.'/certificate-template.php'; ?></main>
</body></html>
