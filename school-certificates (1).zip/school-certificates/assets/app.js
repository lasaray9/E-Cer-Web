'use strict';
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const token=$('meta[name="csrf-token"]').content;
const projectForm=$('#project-form');projectForm.noValidate=true;
const positionLabels={school_y:'ชื่อโรงเรียน',heading_y:'หัวข้อเกียรติบัตร',intro_y:'ข้อความเกริ่น',name_y:'ชื่อนักเรียน',award_y:'ข้อความรับรอง',project_y:'ชื่อโครงการ',date_y:'วันที่มอบ',signature_y:'ภาพลายเซ็น',signer_y:'ชื่อผู้ลงนาม',position_y:'ตำแหน่งผู้ลงนาม'};
let defaults={school_y:14,heading_y:25,intro_y:33,name_y:43,award_y:52,project_y:60,date_y:69,signature_y:76,signer_y:85,position_y:91,name_size:38,text_color:'#172c49',show_border:true};
let current=null,recipients=[],selected=new Set(),page=1,activeTab='recipients',busy=false,projectSequence=0;
$('#layout-controls').innerHTML=Object.entries(positionLabels).map(([key,label])=>`<label>${label}<output id="value-${key}"></output><input type="range" id="layout-${key}" min="5" max="95" step="0.5"></label>`).join('');
async function api(url='api.php',options={}){
 const response=await fetch(url,{credentials:'same-origin',...options});let data;
 try{data=await response.json();}catch(e){throw new Error('เซิร์ฟเวอร์ตอบกลับไม่ถูกต้อง ตรวจสอบ PHP, MySQL และขนาดไฟล์อัปโหลด');}
 if(!response.ok)throw new Error(data.message||'ทำรายการไม่สำเร็จ');return data;
}
function post(action,body){body.set('action',action);body.set('csrf',token);return api('api.php',{method:'POST',body});}
async function notice(message,icon='success'){
 if(window.Swal)return Swal.fire({text:message,icon,confirmButtonText:'ตกลง',confirmButtonColor:'#245bc1'});
 alert(message);
}
function setBusy(value){busy=value;$('#save-project').disabled=value;$('#new-project').disabled=value;$('#add-recipients').disabled=value;}
function showTab(tab){
 if(tab==='recipients'&&!current)tab='project';activeTab=tab;
 for(const key of ['recipients','project','design'])$('#tab-'+key).hidden=key!==tab;
 document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 $('#save-bar').hidden=tab==='recipients';
 if(tab==='design')updateLivePreview();
}
function getLayout(){
 const result={};for(const key of Object.keys(positionLabels))result[key]=Number($('#layout-'+key).value);
 result.name_size=Number($('#name-size').value);result.text_color=$('#text-color').value;result.show_border=$('#show-border').checked;return result;
}
function setLayout(values){
 for(const key of Object.keys(positionLabels))$('#layout-'+key).value=values[key];
 $('#name-size').value=values.name_size;$('#text-color').value=values.text_color;$('#show-border').checked=values.show_border;updateLivePreview();
}
function updateLivePreview(){
 const layout=getLayout();for(const key of Object.keys(positionLabels))$('#value-'+key).textContent=layout[key]+'%';
 $('#name-size-value').textContent=layout.name_size+' px';
 $('#certificate-preview').contentWindow?.postMessage({type:'certificate-layout',layout},location.origin);
}
function setupPreview(){
 $('#preview-placeholder').hidden=!!current;$('#open-preview').disabled=!current;
 $('#certificate-preview').src=current?`certificate.php?project_id=${current.id}&sample=1&embed=1&t=${Date.now()}`:'about:blank';
 for(const kind of ['background','signature']){
  $('#'+kind+'-preview').innerHTML=current?.[kind+'_id']?`<img alt="${kind==='background'?'พื้นหลังปัจจุบัน':'ลายเซ็นปัจจุบัน'}" src="media.php?id=${Number(current[kind+'_id'])}">`:'ยังไม่มีภาพ';
 }
}
async function loadProjects(){
 const data=await api('api.php?action=projects');defaults=data.defaults;$('#project-count').textContent=data.projects.length;
 $('#project-list').innerHTML=data.projects.length?data.projects.map(p=>`<button class="project-item ${current?.id===p.id?'active':''}" data-project="${Number(p.id)}"><strong>${esc(p.title)}</strong><small>${esc(p.school)}</small><small>${Number(p.recipient_count)} รายชื่อ · ${esc(p.certificate_date)}</small></button>`).join(''):'<p class="help">ยังไม่มีโครงการ</p>';
 return data.projects;
}
async function loadProject(id,tab='recipients'){
 const sequence=++projectSequence;$('#global-status').textContent='กำลังโหลดโครงการ…';
 try{
  const data=await api('api.php?action=project&id='+Number(id));if(sequence!==projectSequence)return;
  current=data.project;recipients=data.recipients;selected.clear();page=1;$('#recipient-search').value='';
  projectForm.reset();
  for(const key of ['id','school','title','award','certificate_date','number_prefix','signer_name','signer_position'])projectForm.elements[key].value=current[key];
  $('#school-label').textContent=current.school;$('#project-title').textContent=current.title;
  $('#recipient-count').textContent=recipients.length+' รายชื่อ';
  $('#workspace').hidden=false;$('#welcome').hidden=true;$('#save-status').textContent='';
  setLayout(current.layout);setupPreview();renderRecipients();showTab(tab);
  document.querySelectorAll('[data-project]').forEach(b=>b.classList.toggle('active',Number(b.dataset.project)===Number(current.id)));
  $('#global-status').textContent='';
 }catch(error){if(sequence===projectSequence)$('#global-status').textContent=error.message;}
}
function newProject(){
 if(busy)return;projectSequence++;current=null;recipients=[];selected.clear();projectForm.reset();projectForm.elements.id.value='';
 projectForm.elements.certificate_date.value=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Bangkok',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 $('#global-status').textContent='';$('#school-label').textContent='โครงการใหม่';$('#project-title').textContent='สร้างโครงการ';$('#recipient-count').textContent='0 รายชื่อ';
 $('#workspace').hidden=false;$('#welcome').hidden=true;$('#save-status').textContent='';
 document.querySelectorAll('[data-project]').forEach(b=>b.classList.remove('active'));
 setLayout(defaults);setupPreview();showTab('project');projectForm.elements.school.focus();
}
function filteredRecipients(){const q=$('#recipient-search').value.trim().toLocaleLowerCase('th-TH');return recipients.filter(r=>[r.full_name,r.classroom,r.certificate_number].some(v=>String(v).toLocaleLowerCase('th-TH').includes(q)));}
function visibleRecipients(){const list=filteredRecipients();return list.slice((page-1)*50,page*50);}
function renderRecipients(){
 const list=filteredRecipients();const max=Math.max(1,Math.ceil(list.length/50));page=Math.max(1,Math.min(page,max));const visible=visibleRecipients();
 $('#recipient-rows').innerHTML=visible.map(r=>`<tr><td><input type="checkbox" data-select="${Number(r.id)}" ${selected.has(Number(r.id))?'checked':''} aria-label="เลือก ${esc(r.full_name)}"></td><td><strong>${esc(r.full_name)}</strong></td><td>${esc(r.classroom)||'—'}</td><td><span class="pill">${esc(r.certificate_number)}</span></td><td><button type="button" data-print="${Number(r.id)}">เกียรติบัตร</button><button type="button" data-edit="${Number(r.id)}">แก้ไข</button><button type="button" class="danger" data-delete="${Number(r.id)}">ลบ</button></td></tr>`).join('');
 $('#empty-recipients').textContent=visible.length?'':(recipients.length?'ไม่พบรายชื่อที่ค้นหา':'ยังไม่มีรายชื่อ กด “เพิ่มรายชื่อ” เพื่อเริ่มจัดทำเกียรติบัตร');
 $('#page-info').textContent=`${list.length} รายชื่อ · หน้า ${page} / ${max}`;$('#previous').disabled=page<=1;$('#next').disabled=page>=max;
 $('#select-all').checked=visible.length>0&&visible.every(r=>selected.has(Number(r.id)));
 $('#select-all').indeterminate=visible.some(r=>selected.has(Number(r.id)))&&!$('#select-all').checked;
 $('#print-selected').textContent=`พิมพ์ที่เลือก (${selected.size})`;$('#print-selected').disabled=!selected.size;
}
function printIds(ids){if(!current||!ids.length)return;if(ids.length>100){notice('กรุณาเลือกไม่เกิน 100 คนต่อครั้ง','warning');return;}window.open(`certificate.php?project_id=${current.id}&ids=${ids.join(',')}`,'_blank','noopener');}
for(const id of ['start','new-project'])$('#'+id).addEventListener('click',newProject);
$('#project-list').addEventListener('click',e=>{const b=e.target.closest('[data-project]');if(b&&!busy)loadProject(b.dataset.project);});
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
for(const key of Object.keys(positionLabels))$('#layout-'+key).addEventListener('input',updateLivePreview);
for(const id of ['name-size','text-color','show-border'])$('#'+id).addEventListener('input',updateLivePreview);
$('#reset-layout').addEventListener('click',()=>setLayout(defaults));
$('#certificate-preview').addEventListener('load',updateLivePreview);
$('#open-preview').addEventListener('click',()=>{if(current)window.open(`certificate.php?project_id=${current.id}&sample=1`,'_blank','noopener');});
projectForm.addEventListener('submit',async e=>{
 e.preventDefault();if(busy)return;
 if(!projectForm.checkValidity()){showTab('project');projectForm.reportValidity();return;}
 for(const kind of ['background','signature']){const f=projectForm.elements[kind].files[0];if(f&&f.size>5*1024*1024){showTab('project');$('#save-status').textContent='ภาพแต่ละไฟล์ต้องไม่เกิน 5 MB';return;}}
 const body=new FormData(projectForm);body.set('layout_json',JSON.stringify(getLayout()));const tab=activeTab;
 setBusy(true);$('#save-status').textContent='กำลังบันทึก…';
 try{const result=await post('project_save',body);await loadProject(result.id,tab);await loadProjects();$('#save-status').textContent='บันทึกข้อมูลแล้ว';await notice(result.message);}
 catch(error){$('#save-status').textContent=error.message;}
 finally{setBusy(false);}
});
$('#recipient-search').addEventListener('input',()=>{page=1;renderRecipients();});
$('#previous').addEventListener('click',()=>{page--;renderRecipients();});$('#next').addEventListener('click',()=>{page++;renderRecipients();});
$('#select-all').addEventListener('change',e=>{for(const r of visibleRecipients()){if(e.target.checked)selected.add(Number(r.id));else selected.delete(Number(r.id));}renderRecipients();});
$('#recipient-rows').addEventListener('change',e=>{if(!e.target.matches('[data-select]'))return;const id=Number(e.target.dataset.select);e.target.checked?selected.add(id):selected.delete(id);renderRecipients();});
$('#print-selected').addEventListener('click',()=>printIds([...selected]));
$('#add-recipients').addEventListener('click',()=>{if(!current||busy)return;$('#names-form').reset();$('#names-error').textContent='';$('#names-dialog').showModal();});
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>{if(!busy)$('#'+b.dataset.close).close();}));
document.querySelectorAll('dialog').forEach(d=>d.addEventListener('cancel',e=>{if(busy)e.preventDefault();}));
for(const [formId,action,dialogId,errorId] of [['names-form','recipient_add','names-dialog','names-error'],['edit-form','recipient_save','edit-dialog','edit-error']]){
 $('#'+formId).addEventListener('submit',async e=>{
  e.preventDefault();if(busy||!current)return;const body=new FormData(e.target);body.set('project_id',current.id);const id=current.id;
  const button=e.target.querySelector('[type=submit]');button.disabled=true;setBusy(true);$('#'+errorId).textContent='';
  try{const result=await post(action,body);$('#'+dialogId).close();await loadProject(id);await loadProjects();await notice(result.message);}
  catch(error){$('#'+errorId).textContent=error.message;}
  finally{button.disabled=false;setBusy(false);}
 });
}
$('#recipient-rows').addEventListener('click',async e=>{
 const b=e.target.closest('button');if(!b||busy)return;const id=Number(b.dataset.print||b.dataset.edit||b.dataset.delete);const r=recipients.find(r=>Number(r.id)===id);if(!r)return;
 if(b.dataset.print){printIds([id]);return;}
 if(b.dataset.edit){const f=$('#edit-form');for(const key of ['id','full_name','classroom'])f.elements[key].value=r[key];$('#edit-error').textContent='';$('#edit-dialog').showModal();return;}
 setBusy(true);
 try{
  const confirmed=window.Swal?(await Swal.fire({title:'ลบรายชื่อนี้?',text:`${r.full_name} — เกียรติบัตรเลขที่ ${r.certificate_number} จะไม่สามารถเปิดจากระบบได้อีก`,icon:'warning',showCancelButton:true,confirmButtonText:'ลบรายชื่อ',cancelButtonText:'ยกเลิก',confirmButtonColor:'#b12b41',focusCancel:true})).isConfirmed:confirm('ลบ '+r.full_name+' และเกียรติบัตรของรายชื่อนี้หรือไม่?');
  if(!confirmed)return;const pid=current.id;const body=new FormData();body.set('id',id);body.set('project_id',pid);const result=await post('recipient_delete',body);await loadProject(pid);await loadProjects();await notice(result.message);
 }catch(error){await notice(error.message,'error');}finally{setBusy(false);}
});
setLayout(defaults);
(async()=>{try{const projects=await loadProjects();if(projects.length&&$('#workspace').hidden)await loadProject(projects[0].id);}catch(error){$('#global-status').textContent=error.message;}})();
