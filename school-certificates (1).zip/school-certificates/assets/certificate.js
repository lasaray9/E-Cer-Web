'use strict';
function fitPreview(){if(!document.body.classList.contains('sample'))return;const sheet=document.querySelector('.certificate');const scale=window.innerWidth/sheet.offsetWidth;sheet.style.transform=`scale(${scale})`;document.querySelector('#sheets').style.height=(sheet.offsetHeight*scale)+'px';}
window.addEventListener('resize',fitPreview);fitPreview();
window.addEventListener('message',event=>{
 if(event.origin!==location.origin||event.source!==window.parent||!document.body.classList.contains('sample')||event.data?.type!=='certificate-layout')return;
 const layout=event.data.layout;if(!layout||typeof layout!=='object')return;
 const sheet=document.querySelector('.certificate');
 for(const key of ['school_y','heading_y','intro_y','name_y','award_y','project_y','date_y','signature_y','signer_y','position_y']){
  const value=Number(layout[key]);if(Number.isFinite(value)&&value>=5&&value<=95)sheet.style.setProperty('--'+key,value+'%');
 }
 const size=Number(layout.name_size);if(size>=20&&size<=56)sheet.style.setProperty('--name-size',size+'px');
 if(/^#[a-fA-F0-9]{6}$/.test(layout.text_color))sheet.style.setProperty('--text-color',layout.text_color);
 sheet.classList.toggle('with-border',layout.show_border===true);fitPreview();
});
async function preparePrint(){
 const button=document.querySelector('#print-button');if(!button)return;
 try{
  await Promise.all([...document.images].map(img=>img.decode()));
  await document.fonts.ready;
  button.disabled=false;button.textContent='พิมพ์ / บันทึก PDF';button.addEventListener('click',()=>window.print());
 }catch(error){document.querySelector('#print-status').textContent='โหลดภาพพื้นหลังหรือลายเซ็นไม่สำเร็จ กรุณารีเฟรชหรือตรวจสอบไฟล์ก่อนพิมพ์';button.textContent='ภาพโหลดไม่ครบ';}
}preparePrint();
