<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
$newFiles=[];
try {
 $method=$_SERVER['REQUEST_METHOD'];
 if (!in_array($method,['GET','POST'],true)) {header('Allow: GET, POST');out(['message'=>'ไม่รองรับคำขอนี้'],405);}
 if ($method==='POST'&&!hash_equals($_SESSION['csrf'],text_input($_POST,'csrf'))) out(['message'=>'เซสชันหมดอายุหรือไฟล์ใหญ่เกิน post_max_size กรุณารีเฟรชและลองใหม่'],403);
 session_write_close();
 $pdo=db();
 if ($method==='GET') {
  $action=text_input($_GET,'action','projects');
  if ($action==='projects') {
   $rows=$pdo->query('SELECT p.id,p.title,p.school,p.certificate_date,COUNT(r.id) AS recipient_count FROM projects p LEFT JOIN recipients r ON r.project_id=p.id GROUP BY p.id,p.title,p.school,p.certificate_date ORDER BY p.id DESC')->fetchAll();
   out(['projects'=>$rows,'defaults'=>defaults()]);
  }
  if ($action==='project') {
   $p=project(record_id($_GET));
   $q=$pdo->prepare('SELECT * FROM recipients WHERE project_id=? ORDER BY id DESC');$q->execute([$p['id']]);
   out(['project'=>$p,'recipients'=>$q->fetchAll()]);
  }
  throw new InvalidArgumentException('ไม่พบคำสั่ง');
 }
 $action=text_input($_POST,'action');
 if ($action==='project_save') {
  $id=text_input($_POST,'id')===''?null:record_id($_POST);
  $old=$id?project($id):null;
  $title=field($_POST,'title',200);$school=field($_POST,'school',200);$award=field($_POST,'award',200);
  $date=text_input($_POST,'certificate_date');$d=DateTimeImmutable::createFromFormat('!Y-m-d',$date);
  if (!$d||$d->format('Y-m-d')!==$date||$date<'2000-01-01'||$date>'2100-12-31') throw new InvalidArgumentException('วันที่ไม่ถูกต้อง รองรับ ค.ศ. 2000–2100');
  $signer=field($_POST,'signer_name',150,false);$position=field($_POST,'signer_position',150,false);
  $prefix=field($_POST,'number_prefix',20);
  if (!preg_match('/^[A-Za-z0-9_-]{1,20}$/D',$prefix)) throw new InvalidArgumentException('คำนำหน้าเลขที่ใช้ A–Z, a–z, 0–9, - และ _ เท่านั้น');
  $settings=json_decode(text_input($_POST,'layout_json','{}'),true,512,JSON_THROW_ON_ERROR);
  if (!is_array($settings)) throw new InvalidArgumentException('การจัดวางไม่ถูกต้อง');
  $settings=layout($settings);
  $pdo->beginTransaction();
  $media=[];
  foreach (['background','signature'] as $kind) {
   $media[$kind]=text_input($_POST,'remove_'.$kind)==='1'?null:($old[$kind.'_id']??null);
   $f=$_FILES[$kind]??null;
   if (!$f||$f['error']===UPLOAD_ERR_NO_FILE) continue;
   if (!is_int($f['error'])||$f['error']!==UPLOAD_ERR_OK||!is_uploaded_file($f['tmp_name'])) throw new InvalidArgumentException('อัปโหลดภาพไม่สำเร็จ กรุณาตรวจ upload_max_filesize ใน php.ini');
   if ($f['size']>5*1024*1024) throw new InvalidArgumentException('ภาพแต่ละไฟล์ต้องไม่เกิน 5 MB');
   $info=@getimagesize($f['tmp_name']);
   if (!$info||!in_array($info['mime']??'',['image/png','image/jpeg'],true)||$info[0]>8000||$info[1]>8000||$info[0]*$info[1]>24000000) throw new InvalidArgumentException('รับเฉพาะภาพ PNG/JPG ไม่เกิน 8000 พิกเซลต่อด้านและ 24 ล้านพิกเซล');
   $filename=bin2hex(random_bytes(20)).'.bin';$path=__DIR__.'/storage/'.$filename;
   if (!move_uploaded_file($f['tmp_name'],$path)) throw new RuntimeException('Storage is not writable');
   $newFiles[]=$path;
   $q=$pdo->prepare('INSERT INTO media (filename,mime) VALUES (?,?)');$q->execute([$filename,$info['mime']]);
   $media[$kind]=(int)$pdo->lastInsertId();
  }
  $values=[$title,$school,$award,$date,$signer,$position,$prefix,$media['background'],$media['signature'],json_encode($settings,JSON_THROW_ON_ERROR)];
  if ($id) {
   $q=$pdo->prepare('UPDATE projects SET title=?,school=?,award=?,certificate_date=?,signer_name=?,signer_position=?,number_prefix=?,background_id=?,signature_id=?,layout_json=? WHERE id=?');$q->execute([...$values,$id]);
  } else {
   $q=$pdo->prepare('INSERT INTO projects (title,school,award,certificate_date,signer_name,signer_position,number_prefix,background_id,signature_id,layout_json) VALUES (?,?,?,?,?,?,?,?,?,?)');$q->execute($values);$id=(int)$pdo->lastInsertId();
  }
  $pdo->commit();out(['message'=>'บันทึกโครงการแล้ว','id'=>$id]);
 }
 if ($action==='recipient_add') {
  $pid=record_id($_POST,'project_id');$p=project($pid);
  $lines=preg_split('/\R/u',field($_POST,'names',45000));$items=[];
  foreach ($lines as $line) {
   if (trim($line)==='') continue;
   $parts=explode("\t",$line,2);
   $items[]=[field(['name'=>$parts[0]],'name',200),field(['class'=>$parts[1]??''],'class',80,false)];
  }
  if (!$items||count($items)>200) throw new InvalidArgumentException('กรุณาระบุ 1–200 รายชื่อ ต่อครั้ง');
  $pdo->beginTransaction();
  $insert=$pdo->prepare('INSERT INTO recipients (project_id,full_name,classroom) VALUES (?,?,?)');
  $number=$pdo->prepare('UPDATE recipients SET certificate_number=? WHERE id=?');
  foreach ($items as [$name,$class]) {
   $insert->execute([$pid,$name,$class]);$rid=(int)$pdo->lastInsertId();
   $serial=$p['number_prefix'].'-'.((int)substr($p['certificate_date'],0,4)+543).'-'.str_pad((string)$rid,6,'0',STR_PAD_LEFT);
   $number->execute([$serial,$rid]);
  }
  $pdo->commit();out(['message'=>'เพิ่ม '.count($items).' รายชื่อแล้ว']);
 }
 if ($action==='recipient_save'||$action==='recipient_delete') {
  $rid=record_id($_POST);$pid=record_id($_POST,'project_id');
  $pdo->beginTransaction();$q=$pdo->prepare('SELECT id FROM recipients WHERE id=? AND project_id=? FOR UPDATE');$q->execute([$rid,$pid]);
  if (!$q->fetch()) {$pdo->rollBack();out(['message'=>'ไม่พบรายชื่อ'],404);}
  if ($action==='recipient_save') {
   $name=field($_POST,'full_name',200);$class=field($_POST,'classroom',80,false);
   $q=$pdo->prepare('UPDATE recipients SET full_name=?,classroom=? WHERE id=? AND project_id=?');$q->execute([$name,$class,$rid,$pid]);
  } else {$q=$pdo->prepare('DELETE FROM recipients WHERE id=? AND project_id=?');$q->execute([$rid,$pid]);}
  $pdo->commit();out(['message'=>$action==='recipient_save'?'แก้ไขรายชื่อแล้ว':'ลบรายชื่อแล้ว']);
 }
 throw new InvalidArgumentException('ไม่รองรับคำสั่งนี้');
} catch (Throwable $e) {
 if (isset($pdo)&&$pdo->inTransaction()) $pdo->rollBack();
 foreach ($newFiles as $file) if (is_file($file)) unlink($file);
 if ($e instanceof InvalidArgumentException||$e instanceof JsonException) out(['message'=>$e->getMessage()],422);
 error_log((string)$e);out(['message'=>'ทำรายการไม่สำเร็จ กรุณาตรวจ MySQL, config.php, database.sql และสิทธิ์เขียนโฟลเดอร์ storage'],500);
}
